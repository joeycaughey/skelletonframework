<?php
global $CONFIG;
?>
<script type="text/javascript">

<?php if ($CONFIG["socialmedia"]["facebook"]) : ?>
var facebook_app_id = $CONFIG["socialmedia"]["facebook"]["app_id"];
var facebook_app_id = $CONFIG["socialmedia"]["facebook"]["app_id"];
<?php endif; ?>

</script>