<script type="text/javascript">
var gigya_api_key = '2_l1OJ-y4dnvOEstubuKNmFS21chXeWTTt-Wo0ZJ2TqSYVzmHeOZf85aURcNufEW7e';
if (gigya_api_key) {
	$.getScript('http://cdn.gigya.com/js/socialize.js?apiKey='+gigya_api_key, function() {
		$.getScript('/_assets/gigya/gigya.js', function() { });
	});
}	
</script>