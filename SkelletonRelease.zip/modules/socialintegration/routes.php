<?php 
$routes->set_template("_templates/blank.tpl");
$routes->add_route("module_socialintegration_init_url", "/socialintegration/iconfig/", "modules/socialintegration/frontend/config");

