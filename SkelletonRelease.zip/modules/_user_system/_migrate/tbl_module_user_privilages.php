<?php
global $UserPrivilagesModel;

$UserPrivilagesModel->insert(array("user_id" => 1, "group_id" => 1));
$UserPrivilagesModel->insert(array("user_id" => 2, "group_id" => 2));
$UserPrivilagesModel->insert(array("user_id" => 3, "group_id" => 1));




