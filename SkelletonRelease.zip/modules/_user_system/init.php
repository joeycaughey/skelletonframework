<?php
$ACTIVE_USER = $_SESSION[$sitename]["user"]["authentication"];
