<?php
include("modules/_user_system/admin/profile/".$_GET["partial"].".php");