<?PHP
global $ContactsModel;
$ContactsModel->insert(array("first_name" => "Admin", "last_name" => "Nimda" , "phone" => "412.123.1234"));
$ContactsModel->insert(array("first_name" => "Joey", "last_name" => "Caughey" , "email" => "joey.caughey@gmail.com"));
$ContactsModel->insert(array("first_name" => "TFFL", "last_name" => "Admin" , "email" => "admin@tffl.com"));

