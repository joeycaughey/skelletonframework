<?php
$routes->set_template("_templates/blank.tpl");  						
