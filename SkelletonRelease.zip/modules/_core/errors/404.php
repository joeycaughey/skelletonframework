<h1>ERROR :: There has been a problem making your request</h1>
	
<h2>The page cannot be found</h2>
<p>The page you are looking for might have been removed, had it's name changed,
or is temporarily unavailable.</p>

<p><b>Please try the following:</b></p>
<ul>
	<li> If you typed the page address in the address bar, make sure that it is spelled correctly.</li>
	<li>Take a look through our <a href="<?= get_uri("sitemap_url") ?>">sitemap</a> for the page your looking for.</li>
	<li><a href="javascript: history.back()">Click here</a> to go back</li>
</ul>

HTTP 404 - File not found
