<?php
$MediaModel = new MediaModel;

class MediaModel {
	
	
}