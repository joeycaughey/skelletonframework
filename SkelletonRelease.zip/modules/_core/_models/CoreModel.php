<?php
$CoreModel = new CoreModel;

class CoreModel {
	/*
	function __construct() {
		if(md5(config("license_key"))!="d41d8cd98f00b204e9800998ecf8427e") {
			die('Your copy of FullCMS is illegal and unlicensed. Please contact <a href="mailto:sales@sitemafia.com">sales@sitemafia.com</div> for licensing information.  Any persons attempting to use this software without a license will be prosecuted to the full extent of the law.  ');
		}
	}
	*/
} 