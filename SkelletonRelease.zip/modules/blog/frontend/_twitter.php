<?php
?>
<h2>Twitter <span>Feed&nbsp;</span></h2>

<?php if (true) : ?>
	<p>There are no twitter feed posts.</p>
<?php else : ?>
	<div class="blog_post">
		<h4>Blog Article Title<span>&nbsp;&nbsp;</span></h4>
		<p class="first">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis 
		et augue ipsum... </p>
	</div>
	
	<div class="blog_post">
		<h4>Blog Article Title<span>&nbsp;&nbsp;</span></h4>
		<p class="first">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis 
		et augue ipsum... </p>
	</div>
	
	<div class="blog_post">
		<h4>Blog Article Title<span>&nbsp;&nbsp;</span></h4>
		<p class="first">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis 
		et augue ipsum... </p>
	</div>
<?php endif; ?>
