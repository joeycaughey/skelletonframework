<?php 
include("modules/blog/cms/index.php");
?>