<?php
global $NavigationGroupsModel;
?>
<h1>Other Sections:</h1>
<?= $NavigationGroupsModel->build(2);?>