<?PHP
global $NavigationGroupsModel; 
?>
<div class="limit-width">
    <ul class="navigation">
        <?= $NavigationGroupsModel->build(1);?>
    </ul>
	<h1 class="logo">Official Website Big Soul Productions Inc.</h1>
</div>
